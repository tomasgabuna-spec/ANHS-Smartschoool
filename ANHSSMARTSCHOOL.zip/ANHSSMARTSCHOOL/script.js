/* ==================================
   ANHS SMARTSCHOOL JAVASCRIPT
================================== */


/* ================================
   PAGE NAVIGATION
================================ */

const navItems = document.querySelectorAll(".nav-item");
const pages = document.querySelectorAll(".page");

const pageTitle = document.getElementById("pageTitle");
const pageSubtitle = document.getElementById("pageSubtitle");

const pageNames = {

    dashboard: {
        title: "Dashboard",
        subtitle: "Welcome back, Administrator!"
    },

    students: {
        title: "Students",
        subtitle: "Manage student information and enrollment."
    },

    teachers: {
        title: "Teachers",
        subtitle: "Manage faculty information and assignments."
    },

    classes: {
        title: "Classes & Subjects",
        subtitle: "Manage classes, sections and subjects."
    },

    grades: {
        title: "Grades",
        subtitle: "Manage student grades and assessments."
    },

    schedule: {
        title: "Schedule",
        subtitle: "Manage school schedules and room assignments."
    },

    attendance: {
        title: "Attendance",
        subtitle: "Monitor daily student attendance."
    },

    announcements: {
        title: "Announcements",
        subtitle: "Manage school announcements and notices."
    },

    records: {
        title: "Student Records",
        subtitle: "Access and manage student records."
    },

    parents: {
        title: "Parents / Guardians",
        subtitle: "Manage parent and guardian information."
    },

    reports: {
        title: "Reports",
        subtitle: "Generate school management reports."
    },

    settings: {
        title: "Settings",
        subtitle: "Configure ANHS SmartSchool."
    }

};


function showPage(pageName) {

    pages.forEach(page => {

        page.classList.remove("active-page");

    });


    const selectedPage =
        document.getElementById(pageName);

    if (selectedPage) {

        selectedPage.classList.add("active-page");

    }


    navItems.forEach(item => {

        item.classList.remove("active");

        if (item.dataset.page === pageName) {

            item.classList.add("active");

        }

    });


    if (pageNames[pageName]) {

        pageTitle.textContent =
            pageNames[pageName].title;

        pageSubtitle.textContent =
            pageNames[pageName].subtitle;

    }


    /* Close sidebar on mobile */

    document
        .getElementById("sidebar")
        .classList.remove("open");


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* Navigation links */

navItems.forEach(item => {

    item.addEventListener("click", function(event) {

        event.preventDefault();

        showPage(this.dataset.page);

    });

});


/* Quick action buttons */

document.querySelectorAll("[data-page]")
    .forEach(button => {

        if (!button.classList.contains("nav-item")) {

            button.addEventListener("click", function() {

                showPage(this.dataset.page);

            });

        }

    });


/* ================================
   MOBILE SIDEBAR
================================ */

const menuToggle =
    document.getElementById("menuToggle");

const sidebar =
    document.getElementById("sidebar");

menuToggle.addEventListener("click", function() {

    sidebar.classList.toggle("open");

});


/* ================================
   STUDENT SEARCH
================================ */

const studentSearch =
    document.getElementById("studentSearch");

if (studentSearch) {

    studentSearch.addEventListener("input", function() {

        const searchValue =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll(
                "#studentTable tbody tr"
            );

        rows.forEach(row => {

            const text =
                row.textContent.toLowerCase();

            row.style.display =
                text.includes(searchValue)
                    ? ""
                    : "none";

        });

    });

}


/* ================================
   STUDENT MODAL
================================ */

const modal =
    document.getElementById("studentModal");

const addStudentBtn =
    document.getElementById("addStudentBtn");

const closeModal =
    document.getElementById("closeModal");

const cancelModal =
    document.getElementById("cancelModal");


function openStudentModal() {

    modal.classList.add("show");

}


function hideStudentModal() {

    modal.classList.remove("show");

}


if (addStudentBtn) {

    addStudentBtn.addEventListener(
        "click",
        openStudentModal
    );

}


closeModal.addEventListener(
    "click",
    hideStudentModal
);


cancelModal.addEventListener(
    "click",
    hideStudentModal
);


/* Close modal by clicking background */

modal.addEventListener("click", function(event) {

    if (event.target === modal) {

        hideStudentModal();

    }

});


/* ================================
   ADD STUDENT
================================ */

const studentForm =
    document.getElementById("studentForm");


studentForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const id =
            document.getElementById(
                "newStudentId"
            ).value;

        const name =
            document.getElementById(
                "newStudentName"
            ).value;

        const grade =
            document.getElementById(
                "newStudentGrade"
            ).value;

        const section =
            document.getElementById(
                "newStudentSection"
            ).value;


        const tbody =
            document.querySelector(
                "#studentTable tbody"
            );


        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td>${id}</td>

            <td>${name}</td>

            <td>${grade}</td>

            <td>${section}</td>

            <td>
                <span class="status active">
                    Active
                </span>
            </td>

            <td>

                <button class="table-btn">

                    <i class="fa-solid fa-eye"></i>

                </button>

            </td>

        `;


        tbody.appendChild(row);


        /* Update student count */

        const countElement =
            document.getElementById(
                "studentCount"
            );


        let currentCount =
            parseInt(
                countElement.textContent.replace(
                    ",",
                    ""
                )
            );


        currentCount++;


        countElement.textContent =
            currentCount.toLocaleString();


        studentForm.reset();

        hideStudentModal();


        alert(
            "Student successfully added to ANHS SmartSchool."
        );

    }
);


/* ================================
   NOTIFICATION
================================ */

const notificationBtn =
    document.querySelector(
        ".notification-btn"
    );


notificationBtn.addEventListener(
    "click",
    function() {

        alert(
            "You have 3 new notifications."
        );

    }
);


/* ================================
   LOGOUT
================================ */

const logoutBtn =
    document.querySelector(
        ".logout-btn"
    );


logoutBtn.addEventListener(
    "click",
    function() {

        const confirmLogout =
            confirm(
                "Are you sure you want to logout?"
            );


        if (confirmLogout) {

            alert(
                "Logout functionality will be connected to the authentication system."
            );

        }

    }
);


/* ================================
   REPORT BUTTONS
================================ */

document.querySelectorAll(
    ".report-card .outline-btn"
).forEach(button => {

    button.addEventListener(
        "click",
        function() {

            alert(
                "Report generation will be connected to the database."
            );

        }
    );

});


/* ================================
   INITIALIZE
================================ */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        showPage("dashboard");

    }
);